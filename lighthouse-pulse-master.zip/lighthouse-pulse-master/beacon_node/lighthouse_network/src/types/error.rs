// generates error types

use error_chain::error_chain;

error_chain! {}
