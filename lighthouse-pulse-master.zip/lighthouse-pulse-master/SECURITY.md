# Security Policy

## Supported Versions

Please see [Releases](https://gitlab.com/pulsechaincom/lighthouse-pulse/-/releases). We recommend using the most recently released version.
